/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package question2prog6112tht;

/**
 *
 * @author matth
 */
public interface iEstateAgent {
    //interface for estateagent
    String getAgentName();
    double getPropertyPrice();
    double getAgentCommission();
}
