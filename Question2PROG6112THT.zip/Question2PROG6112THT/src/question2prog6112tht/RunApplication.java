/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question2prog6112tht;

import java.util.Scanner;

/**
 *
 * @author matth
 */
public class RunApplication {
    
    public void Start() {
        //declare variables
        String agentName;
        double propertyPrice;
        double commission = 0.2;

        //decalre scanner for user inputs
        Scanner kb = new Scanner(System.in);
        //ask user for input
        System.out.println("Enter the current estate agents name: ");
        agentName = kb.nextLine();
        System.out.println("Enter the property price: ");
        propertyPrice = kb.nextDouble();
        
        //instantiate EstateAgentSales class
        EstateAgentSales eas = new EstateAgentSales(agentName, propertyPrice, commission);
        eas.printPropertyReport();
    }
    
}
