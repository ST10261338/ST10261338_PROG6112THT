/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question2prog6112tht;

/**
 *
 * @author matth
 */
abstract class EstateAgent implements iEstateAgent{
    //initializing variables
    private String agentName;
    private double propertyPrice;
    private double agentCommission;

    //constructor for class
    public EstateAgent(String agentName, double propertyPrice, double agentCommision) {
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
        this.agentCommission = agentCommision;
    }

    @Override
    public String getAgentName() {
        return agentName;
    }

    @Override
    public double getPropertyPrice() {
        return propertyPrice;
    }

    @Override
    public double getAgentCommission() {
        return agentCommission;
    }
}
