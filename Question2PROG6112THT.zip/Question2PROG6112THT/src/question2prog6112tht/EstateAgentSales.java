/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question2prog6112tht;

/**
 *
 * @author matth
 */
public class EstateAgentSales extends EstateAgent {
    
    public EstateAgentSales(String agentName, double propertyPrice, double agentCommision) {
        super(agentName, propertyPrice, agentCommision);
    }
    
    public void printPropertyReport() {
        //writes the report
        System.out.println(""
                + "\nESTATE AGENT REPORT"
                + "\n*********************"
                + "\nESTATE AGENT NAME: " + getAgentName()
                + "\nPROPERTY PRICE: R" + getPropertyPrice()
                + "\nAGENT COMMISSION: R" + (getPropertyPrice() * getAgentCommission()));
}
    
}
