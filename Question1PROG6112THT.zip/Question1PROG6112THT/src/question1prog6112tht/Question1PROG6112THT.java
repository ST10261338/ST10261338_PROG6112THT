/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question1prog6112tht;

/**
 *
 * @author matth
 */
public class Question1PROG6112THT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //array declaration
        String brand [] = {"Canon", "Sony", "Nikon"};
        int prices [][] = { { 10500, 8500 } , {9500,7200} , {12000,8000}};
        String difference [] = new String [3];
        
        //declaring variables
        int larDiffVal = 0;
        String larStrVal = null;
        
        //for loop to set price differences
        for (int i = 0; i < 3; i++) {
            int tempVal = prices[i][0] - prices[i][1];
            if (tempVal < 2500) {
                difference[i] = "R"+ tempVal;
            } else {
                difference[i] = "R" + tempVal + " ***";
            }
            //checking which brand has the largest difference
            if (tempVal > larDiffVal) {
                larDiffVal = tempVal;
                larStrVal = brand[i];
            }
        }
        System.out.println("---------------------------------------------------"
                + "\nCamera Technology Report"
                + "\n---------------------------------------------------"
                + "\n\t\t\tMIRRORLESS\t\tDSLR"
                + "\n" + brand[0]+"\t\t\tR" + prices[0][0] + "\t\t\tR" + prices[0][1]
                + "\n" + brand[1]+"\t\t\tR" + prices[1][0] + "\t\t\tR" + prices[1][1]
                + "\n" + brand[2]+"\t\t\tR" + prices[2][0] + "\t\t\tR" + prices[2][1]
                + "\n---------------------------------------------------"
                + "\n" + brand[0] + "\t\t\t" + difference[0]
                + "\n" + brand[1] + "\t\t\t" + difference[1]
                + "\n" + brand[2] + "\t\t\t" + difference[2]
                + "\n"
                + "\nCAMERA WITH THE MOST COST DIFFERENCE: " + larStrVal
                + "\n---------------------------------------------------");
    }
    
}
